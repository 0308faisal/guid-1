﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'fastimage', 'fr', {
	title: 'Upload a new image',
	noFileSelected: 'No file selected',
	maxSizeMessage: 'Image size must lower than % Mb',
	invalidWidth: 'Width must be a number greater than 0',
	invalidHeight: 'Height must be a number greater than 0'
});
