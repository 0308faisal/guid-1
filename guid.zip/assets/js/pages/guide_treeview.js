$(document).ready(function () { 
    
});